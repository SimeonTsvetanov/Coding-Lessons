import random

def game(num_digits):
    listnum = [random.randint(0,9) for n in range(num_digits)]
    print("Type 'give up' to see the answer")

    count=0
    while True:
        count+=1
        
        print("Please guess " + str(num_digits) + "-digit number: ")
        guess = input()
		
        if guess == "give up":
            print(f"You gave up, the number is: {str(listnum)}")
            break
		
        else:
            guess = [int(i) for i in guess]

        if guess == listnum:
            print("You won.")
            print(f"It took you {str(count)} guess(es).")
            break

        else:
            cow=0
            bull=0

            for x in range(0,num_digits):
                if guess[x]==listnum[x]:
                    cow += 1
                elif guess[x] in listnum:
                    bull += 1

        print(f"Cows: {str(cow)} Bulls: {str(bull)}")
        print("++++++++++++++++")

game(4)