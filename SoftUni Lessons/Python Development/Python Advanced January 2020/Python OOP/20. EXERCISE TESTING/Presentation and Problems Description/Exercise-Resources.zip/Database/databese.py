
class Database:
    def __init__(self, data):
        self.__data = [0] * 16
        for _ in range(len(data)):
            self.add(data)
        self.__count = len(data)
    
    @property
    def count(self):
        return self.__count
    
    def add(self, element):
        if self.__count == 16:
            raise Exception("Array's capacity must be exactly 16 integers!")
        self.__data[self.__count] = element
        self.__count += 1
    
    def remove(self):
        if self.__count == 0:
            raise Exception("The collection is empty!")
        self.__count -= 1
        self.__data[self.__count] = 0
    
    def fetch(self):
        new_data = [0] * self.__count
        for i in range(len(new_data)):
            new_data[i] = self.__data[i]
        return new_data

import unittest

class Tests(unittest.TestCase):
    def test(self):
        db = Database(10)
        self.assertEqual(len(db.__data), 16)