class Wrapper:
    class Person:
        def __init__(self, id, username):
            self.__id = id
            self.__username = username
        
        @property
        def username(self):
            return self.__username
        
        @property
        def id(self):
            return self.__id

    class ExtendedDatabase:
        def __init__(self, people):
            self.__people = [0] * 16
            self.add_people(people)
        
        @property
        def count(self):
            return self.__count
        
        def add_people(self, people):
            if len(people) > 16:
                raise Exception("Provided data length should be in range [0..16]!")
            for i in range(len(people)):
                self.add(people[i])
            self.__count = len(people)

        def add(self, person):
            if self.__count == 16:
                raise Exception("Array's capacity must be exactly 16 integers!")
            if any(x.username == person.username for x in self.__people):
                raise Exception("There is already user with this username!")
            if any(x.id == person.id for x in self.__people):
                raise Exception("There is already user with this Id!")
            self.__people[self.__count] = person
            self.count += 1

        def remove(self):
            if self.__count == 0:
                raise Exception()
            self.__count -= 1
            self.__people[self.__count] = None
        
        def find_by_username(self, username):
            if not username:
                raise Exception("Username parameter is None!")
            if all(x.username != username for x in self.__people):
                raise Exception("No user is present by this username!")
            return [x for x in self.__people if x.name == username][0]
        
        def find_by_id(self, id):
            if id < 0:
                raise Exception("Id should be a positive number!")
            if all(x.id != id for x in self.__people):
                raise Exception("No user is present by this ID!")
            return [x for x in self.__people if x.id == id][0]
        

import unittest

class Tests(unittest.TestCase):
    def test_person(self):
        p = Wrapper.Person(10, "Peter")
        self.assertEqual(p.username, "Peter")
        self.assertEqual(p.id, 10)

if __name__ == '__main__':
    unittest.main()