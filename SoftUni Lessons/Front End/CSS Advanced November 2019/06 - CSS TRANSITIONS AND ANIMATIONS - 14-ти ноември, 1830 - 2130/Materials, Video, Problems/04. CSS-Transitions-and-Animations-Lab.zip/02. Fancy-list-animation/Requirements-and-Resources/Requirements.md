﻿# 02 - Fancy list animation
------
Problems for in-class lab for the [“CSS Advanced”](https://softuni.bg/trainings/2427/css-advanced-july-2019) course @ **SoftUni**.

## Tasks
* Change the document **title** to *Fancy list animation*
* Create a list of items with icons
* Animatе the showing of each element
* Use animation-delay to make the appearance of the elements staggered
