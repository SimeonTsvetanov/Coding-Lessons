﻿# 04 - Border Animation
------
Problems for in-class lab for the [“CSS Advanced”](https://softuni.bg/trainings/2427/css-advanced-july-2019) course @ **SoftUni**.


## Tasks
* Create **index.html** and **style.css** files
* Change the document **title** to *Border Animation*
* Use **a** tag to create two buttons
* Set the buttons **outline** to be 5px with dark blue color
* When the buttons are **hover** change the outline width

