﻿# 01 - Circle to square animation
------
Problems for in-class lab for the [“CSS Advanced”](https://softuni.bg/trainings/2427/css-advanced-july-2019) course @ **SoftUni**.


## Constraints
* Create **index.html** and **style.css** files
* Change the document **title** to *Circle to square animation*
* Create a small red circle
* Center the circle in the viewport
* Animate that circle to a square and back to circle
