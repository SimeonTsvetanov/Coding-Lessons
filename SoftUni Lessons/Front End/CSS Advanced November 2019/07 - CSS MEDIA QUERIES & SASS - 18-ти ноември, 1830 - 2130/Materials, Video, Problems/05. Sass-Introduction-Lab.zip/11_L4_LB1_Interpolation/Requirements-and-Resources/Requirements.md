# 01. Sass Interpolation and Parent selector

## Tasks
- Use **SASS interpolation** with parent selector in main styles to generate **name-spaced class names**
