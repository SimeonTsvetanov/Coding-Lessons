# 02. Sass Parent Selector

## Tasks
- Update styles to make **extensive use** of parent selector - where applicable
