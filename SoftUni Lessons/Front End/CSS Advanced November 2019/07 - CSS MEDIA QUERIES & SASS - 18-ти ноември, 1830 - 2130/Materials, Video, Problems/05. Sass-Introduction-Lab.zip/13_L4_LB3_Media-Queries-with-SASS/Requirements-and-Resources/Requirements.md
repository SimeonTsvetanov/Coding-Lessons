# 03. Media Queries: Sass Mixin

## Tasks
- Write a **Map** of all media query sizes
- Write a **mixin** for Media queries with **predefine Map** of sizes and **@content directive**
