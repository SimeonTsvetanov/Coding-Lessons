﻿# 03 - Using Grid Named areas
------
Problems for in-class lab for the [“CSS Advanced”](https://softuni.bg/trainings/2427/css-advanced-july-2019) course @ **SoftUni**.

## Tasks
* Copy the code from **Basic blog layout with Grid** - exercise 2
* Changed the **grid** definition to use named areas
* Update the element placing to use the **named areas**
